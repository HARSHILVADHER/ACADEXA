<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Calendar</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    :root {
      --primary: #4361ee;
      --primary-light: #e0e7ff;
      --primary-dark: #3a0ca3;
      --secondary: #3f37c9;
      --accent: #f72585;
      --dark: #1a1a1a;
      --light: #f8f9fa;
      --gray: #6c757d;
      --light-gray: #e9ecef;
      --success: #4cc9f0;
      --warning: #f8961e;
      --danger: #ef233c;
      --white: #ffffff;
      --card-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
      --card-shadow-hover: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
      --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    }
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Inter', sans-serif;
    }
    body {
      background-color: #f8fafc;
      color: #1a202c;
      font-family: 'Inter', sans-serif;
      margin: 0;
      padding: 0;
    }
    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 18px 40px;
      background: var(--white);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
      position: sticky;
      top: 0;
      z-index: 100;
    }
    .logo {
      font-size: 1.8rem;
      font-weight: 800;
      background: linear-gradient(135deg, var(--primary), var(--primary-dark));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      letter-spacing: -0.5px;
      background-clip: text;
    }
    nav {
      display: flex;
      gap: 15px;
    }
    nav a {
      text-decoration: none;
      color: var(--gray);
      font-weight: 600;
      padding: 8px 16px;
      border-radius: 8px;
      transition: var(--transition);
      position: relative;
      font-size: 0.95rem;
    }
    nav a::after {
      content: '';
      position: absolute;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      width: 0;
      height: 3px;
      background: var(--primary);
      border-radius: 3px;
      transition: var(--transition);
    }
    nav a:hover {
      color: var(--primary);
    }
    nav a:hover::after {
      width: 70%;
    }
    nav a.active {
      color: var(--primary);
      background: var(--primary-light);
    }
    nav a.active::after {
      width: 70%;
    }
    @media (max-width: 768px) {
      header {
        padding: 15px 20px;
        flex-direction: column;
        gap: 15px;
      }
      nav {
        width: 100%;
        overflow-x: auto;
        padding-bottom: 10px;
      }
    }
    .calendar-wrapper {
      display: flex;
      flex-direction: row;
      gap: 40px;
      padding: 32px 24px 0 24px;
      width: 100%;
      max-width: 100vw;
    }
    .calendar-main {
      flex: 2 1 0;
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.04);
      padding: 18px 18px 8px 18px;
      min-width: 600px;
      width: 100%;
    }
    @media (min-width: 1400px) {
      .calendar-main {
        min-width: 1000px;
        max-width: 1600px;
      }
    }
    .calendar-sidebar {
      width: 260px;
      background: linear-gradient(135deg, #e0e7ff 0%, #cddafd 100%);
      border-radius: 18px;
      box-shadow: 0 8px 32px rgba(67,97,238,0.10), 0 2px 8px rgba(0,0,0,0.08);
      padding: 28px 22px 14px 22px;
      height: 650px;
      overflow-y: auto;
      position: relative;
      animation: sidebarPop 0.7s cubic-bezier(.4,2,.6,1) both;
    }
    @keyframes sidebarPop {
      0% { transform: translateX(-40px) scale(0.95); opacity: 0; }
      100% { transform: translateX(0) scale(1); opacity: 1; }
    }
    .sidebar-title {
      font-weight: 800;
      color: #4361ee;
      margin-bottom: 18px;
      font-size: 1.6rem;
      letter-spacing: 1px;
      text-shadow: 0 2px 8px #e0e7ff;
      display: flex;
      align-items: center;
      gap: 10px;
      animation: fadeInTitle 1s 0.2s both;
    }
    @keyframes fadeInTitle {
      0% { opacity: 0; transform: translateY(-20px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    .add-task-btn {
      background: linear-gradient(90deg, #4361ee 60%, #4cc9f0 100%);
      color: #fff;
      border: none;
      padding: 12px 0;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 700;
      cursor: pointer;
      margin-bottom: 22px;
      margin-top: 8px;
      transition: background 0.2s, box-shadow 0.2s, transform 0.2s;
      width: 100%;
      box-shadow: 0 2px 8px rgba(67,97,238,0.10);
      letter-spacing: 0.5px;
      animation: fadeInBtn 1s 0.4s both;
    }
    .add-task-btn:hover {
      background: linear-gradient(90deg, #3f37c9 60%, #4cc9f0 100%);
      transform: translateY(-2px) scale(1.03);
      box-shadow: 0 6px 18px rgba(67,97,238,0.18);
    }
    @keyframes fadeInBtn {
      0% { opacity: 0; transform: scale(0.95); }
      100% { opacity: 1; transform: scale(1); }
    }
    .calendar-list {
      margin-bottom: 18px;
      animation: fadeInList 1s 0.6s both;
    }
    @keyframes fadeInList {
      0% { opacity: 0; transform: translateY(20px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    .calendar-list label {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 6px;
      font-size: 15px;
      cursor: pointer;
    }
    .calendar-list input[type="checkbox"] {
      accent-color: #2563eb;
    }
    .fc-toolbar-title {
      font-size: 1.3rem;
      font-weight: 500;
    }
    .fc .fc-button-primary {
      background: #fff;
      color: #222;
      border: 1px solid #e5e7eb;
      box-shadow: none;
    }
    .fc .fc-button-primary.fc-button-active, .fc .fc-button-primary:focus {
      background: #2563eb;
      color: #fff;
      border-color: #2563eb;
    }
    .fc .fc-button-primary:hover {
      background: #2563eb;
      color: #fff;
      border-color: #2563eb;
    }
    .fc .fc-daygrid-day.fc-day-today {
      background: #f3f4f6;
    }
    .fc .fc-col-header-cell-cushion {
      font-weight: 600;
      color: #222;
    }
    .fc .fc-daygrid-day-number {
      color: #222;
    }
    .fc .fc-toolbar-chunk button {
      margin-right: 6px;
    }
    .add-task-btn {
      background: #2563eb;
      color: #fff;
      border: none;
      padding: 10px 18px;
      border-radius: 6px;
      font-size: 15px;
      cursor: pointer;
      margin-bottom: 18px;
      margin-top: 8px;
      transition: background 0.2s;
      width: 100%;
    }
    .add-task-btn:hover {
      background: #1e40af;
    }
    .modal {
      display: none;
      position: fixed;
      z-index: 9999;
      left: 0; top: 0; width: 100vw; height: 100vh;
      background: rgba(0,0,0,0.2);
      justify-content: center;
      align-items: center;
    }
    .modal.show {
      display: flex;
    }
    .modal-content {
      background: #fff;
      padding: 32px 28px 18px 28px;
      border-radius: 18px;
      min-width: 340px;
      max-width: 95vw;
      box-shadow: 0 8px 32px rgba(37,99,235,0.18), 0 2px 8px rgba(0,0,0,0.08);
      position: relative;
      animation: modalPop 0.25s cubic-bezier(.4,2,.6,1) both;
    }

    @keyframes modalPop {
      0% { transform: scale(0.85); opacity: 0; }
      100% { transform: scale(1); opacity: 1; }
    }

    .modal-content h2 {
      margin-top: 0;
      margin-bottom: 18px;
      font-size: 1.5rem;
      color: #2563eb;
      text-align: center;
      font-weight: 700;
      letter-spacing: 1px;
    }

    .modal-content label {
      font-weight: 600;
      color: #222;
      margin-bottom: 6px;
      display: block;
    }

    .modal-content input[type="date"],
    .modal-content select {
      width: 100%;
      padding: 8px 10px;
      border-radius: 7px;
      border: 1px solid #e5e7eb;
      margin-bottom: 14px;
      font-size: 1rem;
      background: #f3f4f6;
    }

    #taskFields {
      margin-top: 10px;
    }

    .task-field-group {
      position: relative;
      margin-bottom: 16px;
      padding-bottom: 0;
    }

    .task-field-group textarea {
      width: 100%;
      min-height: 60px;
      margin-bottom: 0;
      resize: vertical;
      border-radius: 7px;
      border: 1px solid #e5e7eb;
      padding: 8px 38px 8px 10px;
      font-size: 1rem;
      background: #f9fafb;
    }

    .delete-task-btn {
      position: absolute;
      right: 8px;
      bottom: 8px;
      background: none;
      border: none;
      color: #ef4444;
      font-size: 1.2rem;
      cursor: pointer;
      padding: 4px;
      border-radius: 50%;
      transition: background 0.2s;
    }

    .delete-task-btn:hover {
      background: #fee2e2;
    }

    .close {
      position: absolute;
      right: 18px;
      top: 12px;
      font-size: 28px;
      color: #888;
      cursor: pointer;
      transition: color 0.2s;
    }
    .close:hover {
      color: #2563eb;
    }
    /* Make calendar event text black and bold */
    .fc-event, .fc-event .fc-event-title {
      color: black !important;
      font-weight: bold !important;
    }
    #taskForm button[type="button"] {
      background: #f1f5f9;
      color: #2563eb;
      border: 1px solid #2563eb;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 15px;
      cursor: pointer;
      margin-bottom: 8px;
      margin-right: 8px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.2s, color 0.2s, border 0.2s;
    }
    #taskForm button[type="button"]:hover {
      background: #2563eb;
      color: #fff;
      border-color: #2563eb;
    }

    #taskForm button[type="submit"] {
      background: #2563eb;
      color: #fff;
      border: none;
      padding: 10px 22px;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
      margin-top: 8px;
      display: inline-block;
    }
    #taskForm button[type="submit"]:hover {
      background: #1e40af;
    }
    #editTaskForm {
      margin-top: 10px;
    }

    #editTaskForm label {
      font-weight: 600;
      color: #222;
      margin-bottom: 6px;
      display: block;
    }

    #editTaskForm select,
    #editTaskForm input[type="date"] {
      width: 100%;
      padding: 8px 10px;
      border-radius: 7px;
      border: 1px solid #e5e7eb;
      margin-bottom: 14px;
      font-size: 1rem;
      background: #f3f4f6;
    }

    #editTaskForm textarea {
      width: 100%;
      min-height: 60px;
      margin-bottom: 0;
      resize: vertical;
      border-radius: 7px;
      border: 1px solid #e5e7eb;
      padding: 8px 38px 8px 10px;
      font-size: 1rem;
      background: #f9fafb;
    }

    #editTaskForm button[type="button"] {
      background: #f1f5f9;
      color: #2563eb;
      border: 1px solid #2563eb;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 15px;
      cursor: pointer;
      margin-bottom: 8px;
      margin-right: 8px;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.2s, color 0.2s, border 0.2s;
    }
    #editTaskForm button[type="button"]:hover {
      background: #2563eb;
      color: #fff;
      border-color: #2563eb;
    }

    #editTaskForm button[type="submit"] {
      background: #2563eb;
      color: #fff;
      border: none;
      padding: 10px 22px;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s;
      margin-top: 8px;
      display: inline-block;
    }
    #editTaskForm button[type="submit"]:hover {
      background: #1e40af;
    }

    #editTaskForm .mark-completed {
      margin-top: 18px;
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 15px;
      color: #222;
    }
    .sidebar-tasks-list ul {
      margin: 0 0 0 8px;
      padding: 0 0 0 10px;
      font-size: 14px;
      color: #444;
    }
    .sidebar-tasks-list li {
      margin-bottom: 4px;
    }
    .sidebar-checkbox {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 15px;
  margin-bottom: 10px;
  padding: 6px 12px;
  border-radius: 6px;
  background: #f3f4f6;
  cursor: pointer;
  transition: background 0.2s;
  margin-right: 8px;
}
.sidebar-checkbox input[type="checkbox"] {
  accent-color: #2563eb;
  width: 18px;
  height: 18px;
}
.sidebar-checkbox:hover {
  background: #e0e7ff;
  box-shadow: 0 2px 8px rgba(67,97,238,0.10);
}

.sidebar-tasks-card {
  background: #f8fafc;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(67,97,238,0.08);
  padding: 16px 14px 10px 14px;
  margin-top: 18px;
  min-height: 60px;
  animation: fadeInTasks 1s 0.8s both;
}
@keyframes fadeInTasks {
  0% { opacity: 0; transform: scale(0.97); }
  100% { opacity: 1; transform: scale(1); }
}

.sidebar-role-title {
  font-weight: 600;
  color: #2563eb;
  margin-bottom: 4px;
  margin-top: 10px;
  font-size: 15px;
}
  </style>
</head>
<body>
    <header>
    <div class="logo">Acadexa</div>
    <nav>
      <a href="dashboard.php" class="active">Home</a>
      <a href="createclass.html">Classes</a>
      <a href="attendance.html">Attendance</a>
      <a href="gradecard.php">Reports</a>
      <a href="inquiry.php">Inquiries</a>
      <a href="profile.php">Profile</a>
    </nav>
  </header>
  <div class="calendar-wrapper">
    <!-- Sidebar -->
    <div class="calendar-sidebar">
      <div class="sidebar-title">Your Task</div>
      <button class="add-task-btn" onclick="openTaskModal()">Add Your Task</button>
      <div class="calendar-list">
        <label class="sidebar-checkbox">
          <input type="checkbox" id="showTrusteeTasks" onchange="toggleSidebarTasks('trustee')">
          Trustee
        </label>
        <label class="sidebar-checkbox">
          <input type="checkbox" id="showAdminTasks" onchange="toggleSidebarTasks('admin')">
          Admin
        </label>
        <label class="sidebar-checkbox">
          <input type="checkbox" id="showTutorTasks" onchange="toggleSidebarTasks('tutor')">
          Tutor
        </label>
      </div>
      <div id="sidebarTasksCard" class="sidebar-tasks-card" style="display:none;">
        <div id="trusteeTasks" class="sidebar-tasks-list"></div>
        <div id="adminTasks" class="sidebar-tasks-list"></div>
        <div id="tutorTasks" class="sidebar-tasks-list"></div>
      </div>
    </div>
    <!-- Main Calendar -->
    <div class="calendar-main">
      <div id="calendar"></div>
    </div>
  </div>

  <div id="taskModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeTaskModal()">&times;</span>
      <h2>Add Task</h2>
      <form id="taskForm">
        <label>Date:</label>
        <input type="date" name="task_date" required><br><br>
        <label>Task For:</label>
        <select name="task_for" required>
          <option value="admin">Admin</option>
          <option value="trustee">Trustee</option>
          <option value="tutor">Tutor</option>
        </select><br><br>
        <div id="taskFields">
          <label>Task:</label>
          <div class="task-field-group">
            <textarea name="task_text[]" required></textarea>
            <!-- Delete button is hidden for the first field -->
          </div>
        </div>
        <button type="button" onclick="addTaskField()" style="margin-top:6px;"><i class="fas fa-plus"></i> Add More</button><br><br>
        <button type="submit">Submit</button>
      </form>
    </div>
  </div>

  <div id="viewTaskModal" class="modal">
    <div class="modal-content">
      <span class="close" onclick="closeViewTaskModal()">&times;</span>
      <h2>Tasks for <span id="viewTaskDate"></span></h2>
      <div id="existingTasks" style="margin-bottom:18px;"></div>
      <form id="editTaskForm">
        <input type="hidden" name="old_task_date" id="oldTaskDate">
        <label>Task For:</label>
        <select name="task_for" id="editTaskFor" required>
          <option value="admin">Admin</option>
          <option value="trustee">Trustee</option>
          <option value="tutor">Tutor</option>
        </select><br><br>
        <label>Date:</label>
        <input type="date" name="task_date" id="editTaskDate" required><br><br>
        <div id="editTaskFields">
          <label>Task:</label>
          <div class="task-field-group">
            <textarea name="task_text[]" required></textarea>
          </div>
        </div>
        <button type="button" onclick="addEditTaskField()" style="margin-top:6px;"><i class="fas fa-plus"></i> Add More</button>
        <button type="submit" style="margin-left:10px;">Update Tasks</button>
        <div class="mark-completed">
          <input type="checkbox" id="markCompleted" name="mark_completed" onclick="confirmDeleteTasks(this)">
          <label for="markCompleted" style="margin:0;cursor:pointer;">Mark as completed (delete all tasks for this date & role)</label>
        </div>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>
  <script>
    var calendar; // Declare globally

    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');
      calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
          left: 'today prev,next',
          center: 'title',
          right: 'dayGridWeek,dayGridMonth,listMonth'
        },
        height: 600,
        selectable: true,
        events: 'get_tasks.php', // <-- Load events from PHP
        eventColor: '#2563eb',   // Default color (can be overridden per event)
      });
      calendar.render();

      // Open the view/edit modal when a day is clicked
      calendar.setOption('dateClick', function(info) {
        openViewTaskModal(info.dateStr);
      });

      // Sidebar month picker sync (if you use it)
      const sidebarMonth = document.getElementById('sidebar-month');
      if (sidebarMonth) {
        sidebarMonth.value = calendar.getDate().toISOString().slice(0,7);
        sidebarMonth.addEventListener('change', function() {
          const [year, month] = this.value.split('-');
          calendar.gotoDate(new Date(year, month - 1, 1));
        });
      }

      // Refresh calendar after adding a task
      document.getElementById('taskForm').onsubmit = function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch('add_task.php', {
          method: 'POST',
          body: formData
        })
        .then(res => res.text())
        .then(data => {
          alert(data.trim());
          closeTaskModal();
          this.reset();
          document.getElementById('taskFields').innerHTML = `<label>Task:</label>
            <textarea name="task_text[]" required></textarea>`;
          calendar.refetchEvents(); // <-- Refresh events after adding
        });
      };
    });

    function openTaskModal() {
      document.getElementById('taskModal').classList.add('show');
    }

    function closeTaskModal() {
      document.getElementById('taskModal').classList.remove('show');
    }

    function addTaskField() {
      const div = document.createElement('div');
      div.className = 'task-field-group';
      div.innerHTML = `
        <textarea name="task_text[]" required style="width:100%;min-height:60px;resize:vertical;"></textarea>
        <button type="button" class="delete-task-btn" title="Delete Task" onclick="deleteTaskField(this)">
          <i class="fas fa-trash"></i>
        </button>
      `;
      document.getElementById('taskFields').appendChild(div);
    }

    function deleteTaskField(btn) {
      btn.parentElement.remove();
    }

    // View Task Modal
    function openViewTaskModal(dateStr) {
      document.getElementById('viewTaskDate').textContent = new Date(dateStr).toLocaleDateString(undefined, {weekday: 'long', year: 'numeric', month: 'short', day: 'numeric'});
      document.getElementById('editTaskDate').value = dateStr;
      document.getElementById('oldTaskDate').value = dateStr; // <-- This ensures the hidden field is set

      // Fetch and show old tasks for this date
      fetch('get_tasks_for_date.php?date=' + encodeURIComponent(dateStr))
        .then(res => res.json())
        .then(tasks => {
          const existingTasksDiv = document.getElementById('existingTasks');
          if (!tasks.length) {
            existingTasksDiv.innerHTML = '<em>No tasks for this day.</em>';
          } else {
            let html = '<ul style="padding-left:18px;">';
            tasks.forEach(task => {
              const [y, m, d] = task.task_date.split('-');
              const formattedDate = `${d} ${m} ${y}`;
              html += `<li><b>${formattedDate}:</b> ${task.task_text}</li>`;
            });
            html += '</ul>';
            existingTasksDiv.innerHTML = html;
            // Optionally, pre-select the first task's role
            document.getElementById('editTaskFor').value = tasks[0].task_for;
          }
          // Always clear and show one empty textarea for new tasks
          document.getElementById('editTaskFields').innerHTML = `
            <label>Task:</label>
            <div class="task-field-group">
              <textarea name="task_text[]" required></textarea>
            </div>
          `;
        });

      document.getElementById('viewTaskModal').classList.add('show');
    }

    function closeViewTaskModal() {
      document.getElementById('viewTaskModal').classList.remove('show');
    }

    function addEditTaskField() {
      const div = document.createElement('div');
      div.className = 'task-field-group';
      div.innerHTML = `
        <textarea name="task_text[]" required style="width:100%;min-height:60px;resize:vertical;"></textarea>
        <button type="button" class="delete-task-btn" title="Delete Task" onclick="deleteEditTaskField(this)">
          <i class="fas fa-trash"></i>
        </button>
      `;
      document.getElementById('editTaskFields').appendChild(div);
    }

    function deleteEditTaskField(btn) {
      btn.parentElement.remove();
    }

    // Handle update form submit
    document.getElementById('editTaskForm').onsubmit = function(e) {
      e.preventDefault();
      const formData = new FormData(this);

      // If mark as completed is checked, send only delete request
      if (document.getElementById('markCompleted').checked) {
        fetch('delete_tasks_for_date.php', {
          method: 'POST',
          body: formData
        })
        .then(res => res.text())
        .then(data => {
          alert(data.trim());
          closeViewTaskModal();
          calendar.refetchEvents();
        });
        return;
      }

      // Otherwise, normal update
      fetch('update_tasks_for_date.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.text())
      .then(data => {
        alert(data.trim());
        closeViewTaskModal();
        calendar.refetchEvents();
      });
    };

    function confirmDeleteTasks(checkbox) {
      if (checkbox.checked) {
        // Show confirmation popup
        if (confirm("Are you sure you want to mark all tasks for this date & role as completed and delete them?")) {
          // Prepare form data
          const form = document.getElementById('editTaskForm');
          const formData = new FormData(form);

          fetch('delete_tasks_for_date.php', {
            method: 'POST',
            body: formData
          })
          .then(res => res.text())
          .then(data => {
            alert(data.trim());
            closeViewTaskModal();
            calendar.refetchEvents();
          });
        } else {
          // If cancelled, uncheck the box
          checkbox.checked = false;
        }
      }
    }

    function toggleSidebarTasks(role) {
  const checkbox = document.getElementById('show' + capitalize(role) + 'Tasks');
  const container = document.getElementById(role + 'Tasks');
  const card = document.getElementById('sidebarTasksCard');
  let anyChecked = (
    document.getElementById('showTrusteeTasks').checked ||
    document.getElementById('showAdminTasks').checked ||
    document.getElementById('showTutorTasks').checked
  );

  if (checkbox.checked) {
    // Fetch tasks for this role
    fetch('get_tasks_for_sidebar.php?role=' + encodeURIComponent(role))
      .then(res => res.json())
      .then(tasks => {
        if (!tasks.length) {
          container.innerHTML = `<div class="sidebar-role-title">${capitalize(role)}:</div><em>No tasks.</em>`;
        } else {
          let html = `<div class="sidebar-role-title">${capitalize(role)}:</div><ul>`;
          tasks.forEach(task => {
            html += `<li><b>${task.task_date}:</b> ${task.task_text}</li>`;
          });
          html += '</ul>';
          container.innerHTML = html;
        }
        container.style.display = 'block';
        card.style.display = 'block';
      });
  } else {
    container.style.display = 'none';
    container.innerHTML = '';
    // Hide card if no checkboxes are checked
    if (!anyChecked) card.style.display = 'none';
  }
}

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
  </script>
</body>
</html>